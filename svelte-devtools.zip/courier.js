(function () {
	'use strict';

	const dom = {
		area: document.createElement('div'),
		x: document.createElement('div'),
		y: document.createElement('div'),
	};

	/** @param {Pick<SvelteBlockDetail, 'type' | 'detail'>} [node] */
	function highlight(node) {
		if (!node || node.type !== 'element' || !node.detail) {
			dom.area.remove();
			dom.x.remove();
			dom.y.remove();
			return;
		}

		const { clientWidth, scrollHeight } = document.documentElement;
		const style = window.getComputedStyle(node.detail);
		const rect = node.detail.getBoundingClientRect();

		// TODO: handle sticky position
		const position = style.position === 'fixed' ? 'fixed' : 'absolute';
		const offset = style.position !== 'fixed' ? window.scrollY : 0;

		dom.area.style.setProperty('z-index', '65536');
		dom.area.style.setProperty('background-color', 'rgba(0, 136, 204, 0.2)');
		dom.area.style.setProperty('position', position);
		dom.area.style.setProperty('top', `${offset + rect.top}px`);
		dom.area.style.setProperty('left', `${rect.left}px`);
		dom.area.style.setProperty('width', `${rect.width}px`);
		dom.area.style.setProperty('height', `${rect.height}px`);

		dom.x.style.setProperty('z-index', '65536');
		dom.x.style.setProperty('border', '0px dashed rgb(0, 136, 204)');
		dom.x.style.setProperty('border-width', '1px 0px');
		dom.x.style.setProperty('position', position);
		dom.x.style.setProperty('top', `${offset + rect.top}px`);
		dom.x.style.setProperty('width', `${clientWidth}px`);
		dom.x.style.setProperty('height', `${rect.height}px`);

		dom.y.style.setProperty('z-index', '65536');
		dom.y.style.setProperty('border', '0px dashed rgb(0, 136, 204)');
		dom.y.style.setProperty('border-width', '0px 1px');
		dom.y.style.setProperty('position', 'absolute');
		dom.y.style.setProperty('left', `${rect.left}px`);
		dom.y.style.setProperty('width', `${rect.width}px`);
		dom.y.style.setProperty('height', `${scrollHeight}px`);

		document.body.appendChild(dom.area);
		document.body.appendChild(dom.x);
		document.body.appendChild(dom.y);
	}

	/**
	 * @param {string} type
	 * @param {Record<string, any>} [payload]
	 */
	function send(type, payload) {
		window.postMessage({ source: 'svelte-devtools', type, payload });
	}

	/**
	 * @param {unknown} value
	 * @returns {any}
	 */
	function clone(value, seen = new Map()) {
		switch (typeof value) {
			case 'function':
				return { __is: 'function', source: value.toString(), name: value.name };
			case 'symbol':
				return { __is: 'symbol', name: value.toString() };
			case 'object': {
				if (value === window || value === null) return null;
				if (Array.isArray(value)) return value.map((o) => clone(o, seen));
				if (seen.has(value)) return {};

				/** @type {Record<string, any>} */
				const o = {};
				seen.set(value, o);

				const descriptors = Object.getOwnPropertyDescriptors(value);
				for (const [key, v] of Object.entries(value)) {
					const { get, writable } = descriptors[key];
					const readonly = !writable || get !== undefined;
					o[key] = { key, value: clone(v, seen), readonly };
				}
				return o;
			}
			default:
				return value;
		}
	}

	/** @param {SvelteBlockDetail} node  */
	function serialize(node) {
		const res = /** @type {SvelteBlockDetail} */ ({
			id: node.id,
			type: node.type,
			tagName: node.tagName,
			detail: {},
		});
		switch (node.type) {
			case 'component': {
				const { $$: internal = {} } = node.detail;
				const captured = node.detail.$capture_state?.() || {};
				const bindings = Object.values(internal.bound || {}).map(
					/** @param {Function} f */ (f) => f.name,
				);
				const props = Object.keys(internal.props || {}).flatMap((key) => {
					const value = clone(captured[key]);
					delete captured[key]; // deduplicate for ctx
					if (value === undefined) return [];

					const bounded = bindings.some((f) => f.includes(key));
					return { key, value, bounded };
				});

				res.detail = {
					attributes: props,
					listeners: Object.entries(internal.callbacks || {}).flatMap(([event, value]) =>
						value.map(/** @param {Function} f */ (f) => ({ event, handler: f.toString() })),
					),
					ctx: Object.entries(captured).map(([key, v]) => ({ key, value: clone(v) })),
				};
				break;
			}

			case 'element': {
				/** @type {Attr[]} from {NamedNodeMap} */
				const attributes = Array.from(node.detail.attributes || []);

				/** @type {NonNullable<SvelteListenerDetail['node']['__listeners']>} */
				const listeners = node.detail.__listeners || [];

				res.detail = {
					attributes: attributes.map(({ name: key, value }) => ({ key, value, readonly: true })),
					listeners: listeners.map((o) => ({ ...o, handler: o.handler.toString() })),
				};
				break;
			}

			case 'text': {
				res.detail = {
					nodeValue: node.detail.nodeValue,
				};
				break;
			}

			case 'iteration':
			case 'block': {
				const { ctx, source } = node.detail;
				const cloned = Object.entries(clone(ctx));
				res.detail = {
					ctx: cloned.map(([key, value]) => ({ key, value, readonly: true })),
					source: source.slice(source.indexOf('{'), source.indexOf('}') + 1),
				};
				break;
			}
		}

		return res;
	}

	/** @type {undefined | SvelteBlockDetail} */
	let current_block;

	const index = {
		/** @type {Map<string | object | Node, SvelteBlockDetail>} */
		map: new Map(),

		/** @param {{ node: SvelteBlockDetail; target?: Node; anchor?: Node }} opts */
		add({ node, target: source, anchor }) {
			this.map.set(node.id, node);
			this.map.set(node.detail, node);

			let target = source && this.map.get(source);
			if (!target || target.container != node.container) {
				target = node.container;
			}
			node.parent = target;

			const sibling = anchor && this.map.get(anchor);
			if (target) {
				const idx = target.children.findIndex((n) => n === sibling);
				if (idx === -1) target.children.push(node);
				else target.children.splice(idx, 0, node);
			}

			send('bridge::courier/node->add', {
				node: serialize(node),
				target: node.parent?.id,
				anchor: sibling?.id,
			});
		},

		/** @param {{ node: SvelteBlockDetail; target?: Node; anchor?: Node }} opts */
		update({ node }) {
			send('bridge::courier/node->update', {
				node: serialize(node),
			});
		},

		/** @param {SvelteBlockDetail} node */
		remove(node) {
			if (!node) return;

			this.map.delete(node.id);
			this.map.delete(node.detail);

			if (node.parent) {
				node.parent.children = node.parent.children.filter((n) => n !== node);
				node.parent = undefined;
			}

			send('bridge::courier/node->remove', {
				node: serialize(node),
			});
		},
	};

	document.addEventListener('SvelteRegisterComponent', ({ detail }) => {
		const { component, tagName } = detail;

		const node = index.map.get(component.$$.fragment);
		if (node) {
			index.map.delete(component.$$.fragment);

			node.detail = component;
			node.tagName = tagName;

			index.update({ node });
		} else {
			// @ts-expect-error - component special case
			index.map.set(component.$$.fragment, {
				type: 'component',
				detail: component,
				tagName,
			});
		}
	});

	/** @type {any} */
	let last_promise;
	document.addEventListener('SvelteRegisterBlock', ({ detail }) => {
		const { type, id, block, ...rest } = detail;
		const current_node_id = crypto.randomUUID();

		if (block.m) {
			const original = block.m;
			block.m = (target, anchor) => {
				const parent = current_block;

				// @ts-expect-error - only the necessities
				const node = /** @type {SvelteBlockDetail} */ ({
					id: current_node_id,
					type: 'block',
					detail: rest,
					tagName: type === 'pending' ? 'await' : type,
					container: parent,
					children: [],
				});

				switch (type) {
					case 'then':
					case 'catch':
						if (!node.container) node.container = last_promise;
						break;

					case 'slot':
						node.type = 'slot';
						break;

					case 'component': {
						const component = index.map.get(block);
						if (component) {
							index.map.delete(block);
							Object.assign(node, component);
						} else {
							node.type = 'component';
							node.tagName = 'Unknown';
							node.detail = {};
							index.map.set(block, node);
						}

						Promise.resolve().then(() => {
							const invalidate = node.detail.$$?.bound || {};
							Object.keys(invalidate).length && index.update({ node });
						});
						break;
					}
				}

				if (type === 'each') {
					let group = parent && index.map.get(parent.id + id);
					if (!group) {
						// @ts-expect-error - each block fallback
						group = /** @type {SvelteBlockDetail} */ ({
							version: '',
							id: crypto.randomUUID(),
							type: 'block',
							tagName: 'each',
							container: parent,
							children: [],
							detail: {
								ctx: {},
								source: detail.source,
							},
						});
						parent && index.map.set(parent.id + id, group);
						index.add({ node: group, target, anchor });
					}

					node.container = group;
					node.type = 'iteration';

					// @ts-expect-error - overloaded nodes
					index.add({ node, target: group, anchor });
				} else {
					index.add({ node, target, anchor });
				}

				current_block = node;

				original(target, anchor);

				current_block = parent;
			};
		}

		if (block.p) {
			const original = block.p;
			block.p = (changed, ctx) => {
				const parent = current_block;
				current_block = index.map.get(current_node_id);
				current_block && index.update({ node: current_block });

				original(changed, ctx);

				current_block = parent;
			};
		}

		if (block.d) {
			const original = block.d;
			block.d = (detaching) => {
				const node = index.map.get(current_node_id);
				if (node) {
					if (node.tagName === 'await') {
						last_promise = node.container;
					}
					index.remove(node);
				}

				original(detaching);
			};
		}
	});

	document.addEventListener('SvelteDOMInsert', ({ detail }) => {
		deep_insert(detail); // { node, target, anchor }

		/** @param {Omit<DocumentEventMap['SvelteDOMInsert']['detail'], 'version'>} opts */
		function deep_insert({ node: element, target, anchor }) {
			const type =
				element.nodeType === Node.ELEMENT_NODE
					? 'element'
					: element.nodeValue && element.nodeValue !== ' '
						? 'text'
						: 'anchor';

			index.add({
				anchor,
				target,
				// @ts-expect-error - missing properties are irrelevant
				node: {
					id: crypto.randomUUID(),
					type,
					detail: element,
					tagName: element.nodeName.toLowerCase(),
					container: current_block,
					children: [],
				},
			});

			element.childNodes.forEach((child) => {
				!index.map.has(child) && deep_insert({ node: child, target: element });
			});
		}
	});

	document.addEventListener('SvelteDOMRemove', ({ detail }) => {
		const node = index.map.get(detail.node);
		if (node) index.remove(node);
	});

	document.addEventListener('SvelteDOMAddEventListener', ({ detail }) => {
		const { node, ...rest } = detail;
		node.__listeners = node.__listeners || [];
		node.__listeners.push(rest);
	});

	document.addEventListener('SvelteDOMRemoveEventListener', ({ detail }) => {
		const { node, event, handler, modifiers } = detail;
		if (!node.__listeners || node.__listeners.length) return;
		node.__listeners = node.__listeners.filter(
			(l) => l.event !== event || l.handler !== handler || l.modifiers !== modifiers,
		);
	});

	document.addEventListener('SvelteDOMSetData', ({ detail }) => {
		const node = index.map.get(detail.node);
		if (!node) return;
		if (node.type === 'anchor') node.type = 'text';
		index.update({ node });
	});

	document.addEventListener('SvelteDOMSetProperty', ({ detail }) => {
		const node = index.map.get(detail.node);
		if (!node) return;
		if (node.type === 'anchor') node.type = 'text';
		index.update({ node });
	});

	document.addEventListener('SvelteDOMSetAttribute', ({ detail }) => {
		const node = index.map.get(detail.node);
		if (!node) return;
		if (node.type === 'anchor') node.type = 'text';
		index.update({ node });
	});

	document.addEventListener('SvelteDOMRemoveAttribute', ({ detail }) => {
		const node = index.map.get(detail.node);
		if (!node) return;
		if (node.type === 'anchor') node.type = 'text';
		index.update({ node });
	});

	// @ts-ignore - for the app to call with `eval`
	window['#SvelteDevTools'] = {
		/**
		 * @param {string} id
		 * @param {string[]} keys
		 * @param {any} value
		 */
		inject(id, keys, value) {
			const { detail: component } = index.map.get(id) || {};
			if (component) {
				const [prop, ...rest] = keys;
				const original = component.$capture_state()[prop];
				if (typeof original === 'object') {
					let ref = original;
					for (let i = 0; i < rest.length - 1; i += 1) {
						ref = ref[rest[i]];
					}
					ref[rest[rest.length - 1]] = value;
					component.$inject_state({ [prop]: original });
				} else {
					component.$inject_state({ [prop]: value });
				}
			}
		},
	};

	const previous = {
		/** @type {HTMLElement | null} */
		target: null,
		style: {
			cursor: '',
			background: '',
			outline: '',
		},

		clear() {
			if (this.target) {
				for (const key in this.style) {
					// @ts-expect-error - trust me TS
					this.target.style[key] = this.style[key];
				}
			}
			this.target = null;
		},
	};

	const inspect = {
		/** @param {MouseEvent} event  */
		handle({ target }) {
			const same = previous.target && previous.target === target;
			const html = target instanceof HTMLElement;
			if (same || !html) return;

			if (previous.target) previous.clear();
			previous.target = target;
			previous.style = {
				cursor: target.style.cursor,
				background: target.style.background,
				outline: target.style.outline,
			};
			target.style.cursor = 'pointer';
			target.style.background = 'rgba(0, 136, 204, 0.2)';
			target.style.outline = '1px dashed rgb(0, 136, 204)';
		},
		/** @param {MouseEvent} event  */
		click(event) {
			event.preventDefault();
			document.removeEventListener('mousemove', inspect.handle, true);
			const node = index.map.get(/** @type {Node} */ (event.target));
			if (node) send('bridge::ext/inspect', { node: serialize(node) });
			previous.clear();
		},
	};

	window.addEventListener('message', ({ data, source }) => {
		// only accept messages from our application or script
		if (source !== window || data?.source !== 'svelte-devtools') return;

		if (data.type === 'bridge::ext/select') {
			const node = index.map.get(data.payload);
			// @ts-expect-error - saved for `devtools.inspect()`
			if (node) window.$n = node.detail;
		} else if (data.type === 'bridge::ext/highlight') {
			const node = index.map.get(data.payload);
			return highlight(node);
		} else if (data.type === 'bridge::ext/inspect') {
			switch (data.payload) {
				case 'start': {
					document.addEventListener('mousemove', inspect.handle, true);
					document.addEventListener('click', inspect.click, {
						capture: true,
						once: true,
					});
					break;
				}
				default: {
					document.removeEventListener('mousemove', inspect.handle, true);
					document.removeEventListener('click', inspect.click, true);
					previous.clear();
				}
			}
		}
	});

})();
